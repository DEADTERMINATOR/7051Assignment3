Controls:
	Quit - Escape (Keyboard) or Back button (Xbox Controller)
	Movement:
		Forward - Up arrow key (Keyboard) or Left stick up (Xbox Controller)
		Backward - Down arrow key (Keyboard) or Left stick down (Xbox Controller)
	Look Around:
		Up - X (Keyboard) or right stick up (Xbox Controller)
		Down - C (Keyboard) or right stick down (Xbox Controller)
		Left - Left arrow key (Keyboard) or right stick left (Xbox Controller)
		Right - Right arrow key (Keyboard) or right stick right (Xbox Controller)
	Collision Toggle - W (Keyboard) or Y button (Xbox Controller)
	Zoom Control: 
		Zoom In - Z (Keyboard) or B button (Xbox Controller) (Note: defaults to highest zoom level)
		Zoom Out - Left Shift & Z (Keyboard) or A button (Xbox Controller)
	Reset Game - Home (Keyboard) or Start button (Xbox Controller)
	Toggle Ambient Lighting - P (Keyboard) or X button (Xbox Controller)
	Toggle Fog - I (Keyboard) or RB (Xbox Controller)

Available FOV levels ("Zoom levels"):
	FOV level 1: 45 degrees (default)
	FOV level 2: 75 degrees
	FOV level 3: 90 degrees